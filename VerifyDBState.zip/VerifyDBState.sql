<!doctype html>
<html class="no-js page-60 app-4500" lang="en">
<head>
<meta http-equiv="x-ua-compatible" content="IE=edge" />
<meta charset="UTF-8" />
<title>Script Editor</title>
<link rel="shortcut icon" href="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/img/favicons/favicon.ico">
<link rel="icon" sizes="16x16" href="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/img/favicons/favicon-16x16.png">
<link rel="icon" sizes="32x32" href="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/img/favicons/favicon-32x32.png">
<link rel="apple-touch-icon" sizes="180x180" href="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/img/favicons/favicon-180x180.png">
<base href="/ords/" />
<link rel="stylesheet" href="https://static.oracle.com/cdn/apex/24.2.8/app_ui/css/Core.min.css?v=24.2.8" type="text/css" />
<link rel="stylesheet" href="https://static.oracle.com/cdn/apex/24.2.8/app_ui/css/Theme-Standard.min.css?v=24.2.8" type="text/css" />

<link rel="stylesheet" href="https://static.oracle.com/cdn/apex/24.2.8/libraries/oracle-fonts/oraclesans-apex.min.css?v=24.2.8" type="text/css" />


<link rel="stylesheet" href="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/css/Core.min.css?v=24.2.8" type="text/css" />
<link rel="stylesheet" href="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/css/Theme-Dark.min.css?v=24.2.8" type="text/css" />

<link rel="stylesheet" href="https://static.oracle.com/cdn/apex/24.2.8/css/apex_builder.min.css?v=24.2.8" type="text/css" />



<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Pragma" content="no-cache" /><meta http-equiv="Expires" content="-1" /><meta http-equiv="Cache-Control" content="no-cache" />
</head>
<body class="  apex-theme-dark" >
<!--[if lte IE 9]><div id="outdated-browser">You are using an outdated web browser. For a list of supported browsers, please reference the Oracle APEX Installation Guide.</div><![endif]-->
<noscript>You must run this product with JavaScript enabled.</noscript>
<a href="#main" id="a_Body_skipToContent">Skip to Main Content</a>

<form role="none" action="wwv_flow.accept?p_context=sql-workshop/script-editor/8915572174764" method="post" name="wwv_flow" id="wwvFlowForm" data-oj-binding-provider="none" novalidate >
<input type="hidden" name="p_flow_id" value="4500" id="pFlowId" /><input type="hidden" name="p_flow_step_id" value="60" id="pFlowStepId" /><input type="hidden" name="p_instance" value="8915572174764" id="pInstance" /><input type="hidden" name="p_page_submission_id" value="MTQyNTY4MjA1NjgyOTk3Mjc2NzI5MjYyNzc2OTQyMjE2MTUxMTY&#x2F;1ab2C25czFq9sMz081RpbWVNe7fO1I-c6wnaib1ZeRjPumMCOJkmsE-CEK62W6aaEvtHnFLumfTWYgow8NLq8Q" id="pPageSubmissionId" /><input type="hidden" name="p_request" value="" id="pRequest" /><input type="hidden" name="p_reload_on_submit" value="A" id="pReloadOnSubmit" /><input type="hidden" value="sql-workshop&#x2F;script-editor&#x2F;8915572174764" id="pContext" /><input type="hidden" value="14256820568299727672926277694221615116" id="pSalt" /><header>
    <div id="R386906063356677524" class="a-Header apex-sql-workshop"  ><div id="R386906446198682887" class="a-Header-col a-Header-col--left"  ><div id="R386906842726682887" class=""  role="region" aria-label="Logo" ><a href="/ords/r/apex/workspace/home?session=8915572174764" class="a-Header-logo" title="Oracle&#x20;APEX&#x20;Home"><span role="img" aria-labelledby="logoLabel" class="a-Header-apexLogo"><span id="logoLabel" class="u-vh">Oracle APEX Home</span></span></a>
</div><div id="R32104702900781739" class=""  role="navigation" aria-label="Oracle&#x20;APEX" ><div id="a_Header_menu" class="a-Header-tabsContainer"  style="display: none;"><ul><li data-id="tab-app-builder" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/apps?session=8915572174764" title="" target="">App Builder</a>
<ul><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/create-application?fb_flow_id=&fb_flow_page_id=&clear=56,103,104,106,130,131,35,227,3020,3000,3001&session=8915572174764" title="" target="">Create</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/import?p460_file_type=FLOW_EXPORT&clear=460&session=8915572174764" title="" target="">Import</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/exportapp?fb_flow_id=&fb_flow_page_id=&clear=4900&session=8915572174764" title="" target="">Export</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="separator" title="" target="">-----</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="" title="" target="">Workspace Utilities</a>
<ul><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/workspace-utilities?session=8915572174764" title="" target="">All Workspace Utilities</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="separator" title="" target="">-----</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/workspace-themes?session=8915572174764" title="" target="">Workspace Themes</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/application-groups?clear=RP&session=8915572174764" title="" target="">Application Groups</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/apex-views?session=8915572174764" title="" target="">Oracle APEX Views</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/app-builder/cross-application-reports?session=8915572174764" title="" target="">Cross Application Reports</a></li>
</ul></li></ul></li><li data-current="true" data-id="tab-sql-workshop" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/sql-workshop?session=8915572174764" title="" target="">SQL Workshop</a>
<ul><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/ob?session=8915572174764" title="" target="">Object Browser</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/sqlcommandprocessor?session=8915572174764" title="" target="">SQL Commands</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/sql-scripts?session=8915572174764" title="" target="">SQL Scripts</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="" title="" target="">Utilities</a>
<ul><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/utilities?session=8915572174764" title="" target="">All Utilities</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="separator" title="" target="">-----</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/data-workshop/data-load-unload?session=8915572174764" title="" target="">Data Workshop</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/blueprints?session=8915572174764" title="" target="">Data Generator</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/querybuilder?session=8915572174764" title="" target="">Query Builder</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/quick-sql?session=8915572174764" title="" target="">Quick SQL</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/data-workshop/select-sample-dataset?session=8915572174764" title="" target="">Sample Datasets</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/generate-ddl?session=8915572174764" title="" target="">Generate DDL</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/ui-defaults?session=8915572174764" title="" target="">UI Defaults</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/schema-comparison?session=8915572174764" title="" target="">Schema Comparison</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/create-package-on-a-table?session=8915572174764" title="" target="">Methods on Tables</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/recycle-bin?session=8915572174764" title="" target="">Recycle Bin</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/object-reports?session=8915572174764" title="" target="">Object Reports</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/about-database?session=8915572174764" title="" target="">About Database</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/sql-workshop/database-monitor?session=8915572174764" title="" target="">Database Monitor</a></li>
</ul></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/rest/ords-restful-services?session=8915572174764" title="" target="">RESTful Services</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="#action$a-dialog-open?url=%2Fords%2Fr%2Fapex%2Fsql-workshop%2Fsql-developer-web%3Fclear%3D64%26session%3D8915572174764%26cs%3D3MHB7p1uBQiy3_Nf1zCEWd13D6Vb6GkxZJCgQPthrLU3RzyuY4JIdnnnDiAv0MfwvJ4M8SS8pFo8IxG2epwE_Ug%26dialogCs%3DgSWdkcTtFZpN41cnVFQVGW0i7ib8vE929Vaado_FevxrNFIOQ6fHxUb6jVX9nt3Xj22mpO0lIgc5YXqVrR1zUA&appId=4500&pageId=64&tmpl=APEX_5.0_DIALOG&title=SQL%20Developer%20Web&h=340&w=480&mxw=1200&isModal=true&dlgCls=&pageCls=&trgEl=%23a_Header_menu" title="" target="">SQL Developer Web</a></li>
</ul></li><li data-id="tab-team-dev" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/team-development/teamdev?clear=RP&session=8915572174764" title="" target="">Team Development</a>
<ul><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/team-development/labels?clear=RP&session=8915572174764" title="" target="">Labels</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/team-development/milestones?clear=RP&session=8915572174764" title="" target="">Milestones</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/team-development/templates?clear=RP&session=8915572174764" title="" target="">Templates</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/team-development/utilities?session=8915572174764" title="" target="">Utilities</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="separator" title="" target="">-----</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/feedback/feedback-dashboard?session=8915572174764" title="" target="">Feedback</a></li>
</ul></li><li data-id="tab-apps" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/gallery/apps?session=8915572174764" title="" target="">Gallery</a></li>
</ul></div></div></div><div id="R386906639708682887" class="a-Header-col a-Header-col--right"  ><div id="R385807144565239746" class="a-Header-navLinks"  role="region" aria-label="Navigation&#x20;Bar" ><div id="adminMenu" class=""  ><div id="adminMenu_menu" class="" style="display:none;"><ul><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/administration?session=8915572174764" title="" target="">Administration</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="separator" title="" target="">------</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="" title="" target="">Manage Service</a><ul><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/manage-service?session=8915572174764" title="" target="">Manage Service</a></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="separator" title="" target="">------</a></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/request-service-identify-request?clear=49&session=8915572174764" title="" target="">Make a Service Request</a></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/set-workspace-preferences?clear=RP&session=8915572174764" title="" target="">Set Workspace Preferences</a></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="#action$a-dialog-open?url=%2Fords%2Fr%2Fapex%2Fworkspace-admin%2Fworkspace-message%3Fsession%3D8915572174764%26dialogCs%3DWFUSqQITOg9NNVh0NJC-z_jn9-XPSpcEBVcFx9uBtHMN5qDjIvTfziosDtPT_42Zm_RRVwKPmaG8GKmIQC85KQ&appId=4350&pageId=35&tmpl=APEX_5.0_DIALOG&title=Workspace%20Message&h=320&w=500&mxw=1200&isModal=true&dlgCls=&pageCls=&trgEl=%23adminMenu_menu&v=15599294797651" title="" target="">Define Workspace Message</a></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="#action$a-dialog-open?url=%2Fords%2Fr%2Fapex%2Fworkspace-admin%2Fenvironment-banner%3Fp105_last_app_id%3D4500%26p105_last_page_id%3D60%26clear%3D105%26session%3D8915572174764%26cs%3D1rtr7v4Vv_-COdMxjNjyF3fercETtjaeBCDOG3TyCNryc_gBIiS4_TGjSl9J6iLeptMJYUk1_of5OMaJgcC6wlQ%26dialogCs%3DJ2z8rRV1XPHmGJGIfQpGroDH178wUVxtLmmxRpGm0i4wY7DDW3sdxfHOd0wjDHxBHq0FAI94Kk4h-F_LH2SHbw&appId=4350&pageId=105&tmpl=APEX_5.0_DIALOG&title=Workspace%20Environment%20Banner&h=480&w=640&mxw=1200&isModal=true&dlgCls=&pageCls=&trgEl=%23adminMenu_menu" title="" target="">Define Environment Banner</a></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/workspace-utilization?session=8915572174764" title="" target="">Workspace Utilization</a></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/links?session=8915572174764" title="" target="">Manage Extension Links</a></li></ul></li><li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/manage-users?session=8915572174764" title="" target="">Manage Users and Groups</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/monitor-activity?session=8915572174764" title="" target="">Monitor Activity</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="/ords/r/apex/workspace-admin/workspace-dashboard?session=8915572174764" title="" target="">Dashboards</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="#action$a-dialog-open?url=%2Fords%2Fr%2Fapex%2Fworkspace-admin%2Fedit-profile%3Fclear%3D3%26session%3D8915572174764%26dialogCs%3DxD-wL1GUMuO1GPB2NGP_scUYVFUwAYJ1eu2gYLDA5b6uyw1TYFCiaF1NCVrXwIT5ANRql6deyFzsoaAPQchvrw%23pwd&appId=4350&pageId=3&tmpl=APEX_5.0_DIALOG&title=Edit%20Profile&h=550&w=600&mxw=1200&isModal=true&dlgCls=&pageCls=&trgEl=%23adminMenu_menu&v=15599294796741" title="" target="">Change My Password</a></li>
</ul></div></div><div id="helpMenu" class=""  ><div id="helpMenu_menu" class="" style="display:none;"><ul><li data-id="helpLinkDocLib" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="https://apex.oracle.com/doc242?context=4500:60" title="" target="">Documentation</a></li>
<li data-id="helpLinkForum" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="https://apex.oracle.com/forum" title="" target="">Discussion Forum</a></li>
<li data-id="helpLinkOTN" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="https://apex.oracle.com" title="" target="">Learn More about Oracle APEX</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="separator" title="" target="">---</a></li>
<li data-id="" data-disabled="" data-hide="" data-shortcut="" data-icon=""><a href="#action$a-dialog-open?url=%2Fords%2Fr%2Fapex%2Fworkspace-admin%2Fabout%3Fsession%3D8915572174764%26dialogCs%3DNUQrRr4HV1nGlfIYifB5qDHqXlZflKrNjQEwlk1haJhCNNsHTECoq7bpbRQrrDsAnzR6Gi9lRb4zOq0c9JDs8Q&appId=4350&pageId=9&tmpl=APEX_5.0_DIALOG&title=About%20Oracle%20APEX&h=500&w=490&mxw=1200&isModal=true&dlgCls=&pageCls=&trgEl=%23helpMenu_menu&v=15599294796894" title="" target="">About</a></li>
</ul></div></div><button class="a-Button a-Button--iconTextButton a-Button--noUI&#x20;a-Button--navLink&#x20;&#x20;a-Button--iconLeft" onclick="void(0);" type="button" id="header-spotlightSearch" data-action="spotlight-search" data-no-update="true">Search<span class="a-Icon icon-search"></span></button><button class="a-Button a-Button--noLabel a-Button--iconTextButton js-menuButton a-Button--noUI&#x20;a-Button--navLink" onclick="void(0);" type="button" title="Administration" aria-label="Administration" id="header-adminMenu" data-menu="adminMenu_menu"><span class="a-Icon icon-gears-alt" aria-hidden="true"></span><span class="a-Icon icon-menu-drop-down" aria-hidden="true"></span></button><button class="a-Button a-Button--noLabel a-Button--iconTextButton js-menuButton a-Button--noUI&#x20;a-Button--navLink" onclick="void(0);" type="button" title="Help" aria-label="Help" id="header-helpMenu" data-menu="helpMenu_menu"><span class="a-Icon icon-help" aria-hidden="true"></span><span class="a-Icon icon-menu-drop-down" aria-hidden="true"></span></button></div><div id="R385816859034290012" class="a-Header-account"  role="navigation" aria-label="Account" ><button class="a-Button a-Button--noLabel a-Button--iconTextButton a-Button--noUI a-Button--navLink a-Button--accountMenu" type="button" aria-description="Account" data-menu="accountMenu_menu" id="header-accountMenu"><span class="a-User a-User--md"><span class="a-User-initials u-color-22" role="presentation" aria-hidden="true" title="Jonathan&#x20;Haynes">JH</span><span class="a-User-name">Jonathan Haynes<span class="a-User-desc">JOHNS_APEX_SPACE</span></span></span><span class="a-Icon icon-menu-drop-down"></span></button><div id="accountMenu_menu" class="a-Header-accountDialog">  <div class="a-MediaBlock a-Menu-content">    <div class="a-MediaBlock-graphic"><span class="a-User a-User--xl"><span class="a-User-initials u-color-22" role="presentation" aria-hidden="true" title="Jonathan&#x20;Haynes">JH</span></span>      <a href="#action$a-dialog-open?url=%2Fords%2Fr%2Fapex%2Fworkspace-admin%2Fedit-profile%3Fsession%3D8915572174764%26dialogCs%3DxD-wL1GUMuO1GPB2NGP_scUYVFUwAYJ1eu2gYLDA5b6uyw1TYFCiaF1NCVrXwIT5ANRql6deyFzsoaAPQchvrw&appId=4350&pageId=3&tmpl=APEX_5.0_DIALOG&title=Edit%20Profile&h=550&w=600&mxw=1200&isModal=true&dlgCls=&pageCls=&trgEl=%23R385816859034290012&v=15599294796741" class="a-Header-accountDialog-editProfile">Edit Profile</a>    </div>    <div class="a-MediaBlock-content">      <div class="a-Menu-label">        <span class="a-Header-dialogText a-Header-dialogName">Jonathan Haynes</span>        <span class="a-Header-dialogText a-Header-dialogUsername">jrhaynesjr@outlook.com</span></div>      <div class="a-Menu-label">        <span class="a-Header-dialogLabel">Workspace</span><span class="a-Header-dialogValue">JOHNS_APEX_SPACE</span></div>      <div class="a-Menu-label"><span class="a-Header-dialogLabel">Role</span><span class="a-Header-dialogValue">Administrator</span></div><div class="a-Header-accountDialog-uiModeSwitch" role="group" aria-label="Appearance"><button type="button" data-mode="auto" class="is-off js-ui-mode-btn a-Menu-item a-Menu-label" role="menuitem" title="Automatic" aria-label="Automatic" aria-current="false"><span class="uiModeSwitch-icon uiModeSwitch-icon-auto"></span></button><button type="button" data-mode="standard" class="is-off js-ui-mode-btn a-Menu-item a-Menu-label" role="menuitem" title="Light&#x20;Mode" aria-label="Light&#x20;Mode" aria-current="false"><span class="uiModeSwitch-icon uiModeSwitch-icon-light"></span></button><button type="button" data-mode="dark" class="is-on js-ui-mode-btn a-Menu-item a-Menu-label" role="menuitem" title="Dark&#x20;Mode" aria-label="Dark&#x20;Mode" aria-current="true"><span class="uiModeSwitch-icon uiModeSwitch-icon-dark"></span></button></div>    </div>  </div>  <div class="a-Header-accountDialog-buttons">    <div class="a-Toolbar">      <div class="a-Toolbar-items a-Toolbar-items--left">        <a href="#action$a-dialog-open?url=%2Fords%2Fr%2Fapex%2Fworkspace-admin%2Fpreferences%3Ff4350_p102_user_id%3D93039214243436666068%26session%3D8915572174764%26dialogCs%3DuKLiYSGkRnkvqRDrWT6CyxUazGTDafbWhaQHkHVUMsCYrVGhfUbnUAYBpjXS3Hj9hz9yLuF4cG8Qtu98_ZuW1g&appId=4350&pageId=102&tmpl=APEX_5.0_DIALOG&title=Preferences&h=480&w=720&mxw=1200&isModal=true&dlgCls=&pageCls=&trgEl=%23R385816859034290012&v=15599294799586" class="a-Button">Preferences</a>      </div>      <div class="a-Toolbar-items a-Toolbar-items--right">        <a href="apex_authentication.logout?p_app_id=4500&p_session_id=8915572174764" class="a-Button">Sign out</a>      </div>    </div>  </div></div>
</div></div></div><div id="R387929033434561917" class="a-ControlBar apex-sql-workshop"  ><div id="R387929284740561918" class="a-ControlBar-col a-ControlBar-col--noPadding"  ><ul class="a-Breadcrumb"><li class="a-Breadcrumb-item"><a href="/ords/r/apex/sql-workshop/sql-workshop?session=8915572174764" class="a-Breadcrumb-label"><span class="u-VisuallyHidden">SQL Workshop</span><span class="a-Icon icon-breadcrumb-previous" title="SQL Workshop"></span></a></li><li class="a-Breadcrumb-item"><a href="/ords/r/apex/sql-workshop/sql-scripts?session=8915572174764" class="a-Breadcrumb-label">SQL Scripts</a></li><li class="a-Breadcrumb-item a-Breadcrumb-item is-active" aria-current="page"><span class="a-Breadcrumb-label">Script Editor</span></li></ul></div><div id="R387929403973561918" class="a-ControlBar-col"  ><div id="apex-control-icons" class="a-Form a-Form--small a-Form--schemaSelect"  ></div></div></div>


</header>

<span id="APEX_SUCCESS_MESSAGE" data-template-id="690783685471803190_S" class="apex-page-success u-hidden"></span><span id="APEX_ERROR_MESSAGE" data-template-id="690783685471803190_E" class="apex-page-error u-hidden"></span><script src="//d.oracleinfinity.io/infy/acs/account/g81cwxmeg3/js/APEX/odc.js"></script>
<script>
// Send Data
var cxDataObject = {
"apex.version":"24.2",
"apex.version.full":"24.2.8",
"apex.app.id": "4500",
"apex.app.lang": "",
"apex.page.id": "60",
"apex.user.workspace.id": "93039214370114666068",
"apex.user.app.id": ""};

function sendIt(data){
// DO NOT EDIT BELOW THIS LINE - ORA.view()
window.ORA = window.ORA || {productReady: []};
ORA.productReady.push(['analytics', function(cxDataObject) {return function() {return ORA.view({"data": cxDataObject})}}(cxDataObject)]);
}

sendIt(cxDataObject);
</script>


  <div id="main" class="a-Body">
    <main class="a-Main">
        <div id="R11140505307196687" class=""  ><input type="hidden" name="OB_OBJECT_NAME" id="OB_OBJECT_NAME" value=""><input type="hidden" name="P0_PPRTIMESTAMP" id="P0_PPRTIMESTAMP" value=""></div><div class="a-ButtonRegion a-ButtonRegion--wizard a-ButtonRegion--withItems a-ButtonRegion--noBorder" id="R8319409375555186"  role="region" aria-labelledby="R8319409375555186_TITLE" >
  <div class="a-ButtonRegion-wrap">
    <div class="a-ButtonRegion-col a-ButtonRegion-col--left"><div class="a-ButtonRegion-buttons"></div></div>
    <div class="a-ButtonRegion-col a-ButtonRegion-col--content">
      <h2 id="R8319409375555186_TITLE" class="a-ButtonRegion-title" data-apex-heading>topbar</h2>
      <div class="a-Form-fieldContainer a-Form-fieldContainer--autoLabelWidth apex-item-wrapper apex-item-wrapper--has-initial-value apex-item-wrapper--text-field has-helpbutton" id="P60_SCRIPT_NAME_CONTAINER"><div class="a-Form-labelContainer">
<label for="P60_SCRIPT_NAME" id="P60_SCRIPT_NAME_LABEL" class="a-Form-label">Script Name</label>
</div><div class="a-Form-inputContainer"><input type="text"  id="P60_SCRIPT_NAME" name="P60_SCRIPT_NAME" class="text_field&#x20;apex-item-text" value="VerifyDBState" size="35" maxlength="70" data-enter-submit="false" data-is-page-item-type="true"  /><button class="a-Button a-Button--noUI a-Button--helpButton js-itemHelp" data-itemhelp="139587000222243903" title="View&#x20;help&#x20;text&#x20;for&#x20;Script&#x20;Name."  aria-label="View&#x20;help&#x20;text&#x20;for&#x20;Script&#x20;Name." tabindex="-1" type="button"><span class="a-Icon icon-help" aria-hidden="true"></span></button><span id="P60_SCRIPT_NAME_error_placeholder" class="a-Form-error" data-template-id="488671029226029669_ET"></span></div></div><input type="hidden" name="P60_OLD_SCRIPT_NAME" id="P60_OLD_SCRIPT_NAME" value="VerifyDBState">
      <div class="a-ButtonRegion-buttons"></div>
    </div>
    <div class="a-ButtonRegion-col a-ButtonRegion-col--right"><div class="a-ButtonRegion-buttons"><button onclick="apex.navigation.redirect(&#x27;\u002Fords\u002Fr\u002Fapex\u002Fsql-workshop\u002Fsql-scripts?session=8915572174764&#x27;);" class="a-Button " type="button"  id="B133522817791564007">Cancel</button><button onclick="void(0);" class="a-Button a-Button--gapRight" type="button"  id="B106549728476820975">Download</button><button onclick="void(0);" class="a-Button " type="button"  id="B91124011966862772">Delete</button><button onclick="void(0);" class="a-Button " type="button"  id="saveButton">Save</button><button onclick="apex.navigation.redirect(&#x27;#action$a-dialog-open?url=\u00252Fords\u00252Fr\u00252Fapex\u00252Fsql-workshop\u00252Fcreate-app-from-script\u00253Fp20_script_file_id\u00253D96285340289618658494\u002526clear\u00253DRP\u00252C20\u002526session\u00253D8915572174764\u002526dialogCs\u00253DxlGRVV1fX4ZQ2deDQ5D2NZo3r0dby0LfSUkuh-kXy85cwIYd3_ajiBIQPIrMbESOFa5hU61JxvSRL0-OcZSqUw\u0026appId=4500\u0026pageId=20\u0026tmpl=APEX_5.0_WIZARD_DIALOG\u0026title=Create\u002520App\u002520from\u002520Script\u0026h=480\u0026w=800\u0026mxw=1200\u0026isModal=true\u0026dlgCls=\u0026pageCls=\u0026trgEl=\u002523B70905955607824816&#x27;);" class="a-Button a-Button--primary" type="button"  id="B70905955607824816">Create App</button><button onclick="void(0);" class="a-Button a-Button--hot " type="button"  id="B106937316772503576">Run</button></div></div>
  </div>
</div><div id="R133086723654895090" ><input type="hidden" name="P60_FILE_ID" id="P60_FILE_ID" value="96285340289618658494"><input type="hidden" name="P60_STORE_TEMP_SCRIPT" id="P60_STORE_TEMP_SCRIPT" value=""><input type="hidden" name="P60_MAX_LENGTH" id="P60_MAX_LENGTH" value="500000"></div><div id="saveDialog"  class="a-DialogRegion js-regionDialog js-draggable js-resizable js-modal"  style="display:none" title="Save Script">
  <div class="a-DialogRegion-body">
<p>A script with this name already exists. Do you wish to overwrite it?</p>
  </div>
  <div class="a-DialogRegion-buttons">
     <div class="a-ButtonRegion a-ButtonRegion--dialogRegion">
       <div class="a-ButtonRegion-wrap">
         <div class="a-ButtonRegion-col a-ButtonRegion-col--left"><div class="a-ButtonRegion-buttons"></div></div>
         <div class="a-ButtonRegion-col a-ButtonRegion-col--right"><div class="a-ButtonRegion-buttons"><button onclick="void(0);" class="a-Button " type="button"  id="CANCEL">Cancel</button><button onclick="void(0);" class="a-Button a-Button--hot " type="button"  id="B138360700895540644">Yes</button></div></div>
       </div>
     </div>
  </div>
</div><div class="a-Region a-Region--noPadding a-Region--accessibleHeader"  role="region" aria-labelledby="codeEditor_heading"  id="codeEditor">
  <div class="a-Region-header">
    <div class="a-Region-headerItems  a-Region-headerItems--title">
      <h2 class="a-Region-title" id="codeEditor_heading" data-apex-heading>Script</h2>
    </div>
    <div class="a-Region-headerItems  a-Region-headerItems--buttons">
      
    </div>
  </div>
  <div class="a-Region-body">
  <div class="a-Region-bodyHeader"></div>
  <div id="codeEditor_widget"><textarea rows="30" cols="60"  style="display: none;" >-- 1. Display database users
SELECT USER_ID, USERNAME, CREATED, PASSWORD_CHANGE_DATE FROM USER_USERS;

-- 2. Display all tables in the database
SELECT * FROM USER_TABLES;

-- 3a. Describe ORDERS table
DESC ORDERS;

-- 3b. Describe PRODUCTLIST table
DESC PRODUCTLIST;

-- 3c. Describe REVIEWS table
DESC REVIEWS;

-- 3d. Describe STOREFRONT table
DESC STOREFRONT;

-- 3e. Describe USERBASE table
DESC USERBASE;

-- 3f. Describe USERLIBRARY table
DESC USERLIBRARY;

-- 4a. Display all data from ORDERS
SELECT * FROM ORDERS;

-- 4b. Display all data from PRODUCTLIST
SELECT * FROM PRODUCTLIST;

-- 4c. Display all data from REVIEWS
SELECT * FROM REVIEWS;

-- 4d. Display all data from STOREFRONT
SELECT * FROM STOREFRONT;

-- 4e. Display all data from USERBASE
SELECT * FROM USERBASE;

-- 4f. Display all data from USERLIBRARY
SELECT * FROM USERLIBRARY;

-- 5. Display constraints present in the database
SELECT TABLE_NAME, CONSTRAINT_NAME, CONSTRAINT_TYPE, STATUS FROM USER_CONSTRAINTS;

-- 6. Display views in the database
SELECT VIEW_NAME, TEXT FROM USER_VIEWS;

-- 7. Display all USERNAME in alphabetical order
SELECT USERNAME FROM USERBASE ORDER BY USERNAME ASC;

-- 8. Display users with Yahoo email
SELECT FIRSTNAME, LASTNAME, USERNAME, PASSWORD, EMAIL 
FROM USERBASE 
WHERE EMAIL LIKE &#x27;%@yahoo.%&#x27;;

-- 9. Display users with less than $25 wallet funds
SELECT USERNAME, BIRTHDAY, WALLETFUNDS 
FROM USERBASE 
WHERE WALLETFUNDS &lt; 25;

-- 10. Display USERID and PRODUCTCODE for users with more than 100 HOURSPLAYED
SELECT USERID, PRODUCTCODE 
FROM USERLIBRARY 
WHERE HOURSPLAYED &gt; 100;

-- 11. Display PRODUCTCODE of games with less than 10 HOURSPLAYED
SELECT PRODUCTCODE 
FROM USERLIBRARY 
WHERE HOURSPLAYED &lt; 10;

-- 12. Display every unique PUBLISHER
SELECT DISTINCT PUBLISHER FROM PRODUCTLIST;

-- 13. Display product details sorted by GENRE
SELECT PRODUCTNAME, RELEASEDATE, PUBLISHER, GENRE 
FROM PRODUCTLIST 
ORDER BY GENRE ASC;

-- 14. Display PRODUCTCODE and PUBLISHER for Strategy games
SELECT PRODUCTCODE, PUBLISHER 
FROM PRODUCTLIST 
WHERE GENRE = &#x27;Strategy&#x27;;

-- 15. Display products costing more than $25 sorted by price descending
SELECT PRODUCTCODE, DESCRIPTION, PRICE 
FROM STOREFRONT
WHERE PRICE &gt; 25 
ORDER BY PRICE DESC;

-- 16. Display inventory and price sorted by price ascending
SELECT INVENTORYID, PRICE 
FROM STOREFRONT 
ORDER BY PRICE ASC;

-- 17. Display reviews with RATING = 1
SELECT PRODUCTCODE, REVIEW 
FROM REVIEWS 
WHERE RATING = 1;

-- 18. Display reviews with RATING &gt;= 4
SELECT PRODUCTCODE, REVIEW 
FROM REVIEWS 
WHERE RATING &gt;= 4;

-- 19. Display every unique USERID from orders
SELECT DISTINCT USERID FROM ORDERS;

-- 20. Display all order data sorted by earliest purchase date
SELECT * FROM ORDERS ORDER BY PURCHASEDATE ASC;
</textarea></div>
  </div>
</div>
    </main>
  </div>
<footer class="a-Footer">
  <div class="a-Footer-info">
    <span class="a-Footer-attribute">
      <span role="img" class="a-Icon icon-user" title="User" aria-label="User"><span class="u-vh">User</span></span>
      JRHAYNESJR@OUTLOOK.COM
    </span>
    <span class="a-Footer-attribute">
      <span role="img" class="a-Icon icon-workspace" title='Workspace' aria-label='Workspace'><span class="u-vh">Workspace</span></span>
      JOHNS_APEX_SPACE
    </span>
    <span class="a-Footer-attribute">
      <span role="img" class="a-Icon icon-language" title="Language" aria-label="Language"><span class="u-vh">Language</span></span>
      en
    </span>
  </div>
  <div class="a-Footer-copyright">Copyright &copy; 1999, 2024, Oracle and/or its affiliates.</div>
  <div class="a-Footer-version">Oracle APEX 24.2.8</div>
</footer>
<input type="hidden" id="pPageFormRegionChecksums" value="&#x5B;&#x5D;">
<input type="hidden" id="pPageItemsRowVersion" value="" /><input type="hidden" id="pPageItemsProtected" value="&#x2F;PGkAz_6aATyc1_dnqOTb9iIzPQWDf3fkwkSycEBY4Jq2p7lp-151wM7YImmLrm-EOgk63lR--GtSoNx6ld24Vg" /></form>


<script nonce="EJWokLq_citvIT9ZcXO3Dw">
var apex_img_dir = "https:\u002F\u002Fstatic.oracle.com\u002Fcdn\u002Fapex\u002F24.2.8\u002F";
var apex = {env: {DB_VERSION: 19,APP_USER: "JRHAYNESJR@OUTLOOK.COM",APP_ID: "4500",APP_PAGE_ID: "60",APP_SESSION: "8915572174764",APP_FILES: "r\u002Fapex\u002F4500\u002Ffiles\u002Fstatic\u002Fv1\u002F",WORKSPACE_FILES: "r\u002Fapex\u002Ffiles\u002Fstatic\u002Fv1\u002F",APEX_VERSION: "24.2.8",APEX_BASE_VERSION: "24.2",COMPATIBILITY_MODE: 24.2,NONCE: "EJWokLq_citvIT9ZcXO3Dw"},
libVersions:{cropperJs:"1.6.2",domPurify:"3.2.4",fontapex:"2.4",fullcalendar:"6.1.15",hammer:"2.0.8",jquery:"3.6.4",jqueryUi:"1.13.2",maplibre:"4.6.0",mapboxGlRtlText:"0.3.0",markedJs:"14.1.2",prismJs:"1.30.0",oraclejet:"17.0.2",turndown:"7.2.0",monacoEditor:"0.51.0",lessJs:"4.2.0",terser:"5.32.0"}};
</script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/libraries/apex/minified/desktop_all.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="wwv_flow.js_messages?p_app_id=4500&p_lang=en&p_version=24.2.8-15647977042413&p_nls_settings=eyJudW1lcmljQ2hhcmFjdGVycyI6Ii4sIiwiY3VycmVuY3kiOiIkIiwiaXNvQ3VycmVuY3kiOiJBTUVSSUNBIiwiZHVhbEN1cnJlbmN5IjoiJCJ9"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="wwv_flow.js_dialogs?p_app_id=4500&p_version=24.2.8-15647977042413"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/libraries/apex/minified/legacy_pre18.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/libraries/apex/minified/legacy_18.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/js/minified/builder_all.min.js?v=24.2.8"></script>

<script nonce="EJWokLq_citvIT9ZcXO3Dw">
apex.da.initDaEventList = function(){
apex.da.gEventList = [
{"triggeringElementType":"BUTTON","triggeringButtonId":"saveButton","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ gStoreScript('SAVE', false, function(saveNew) {
  apex.server.process(saveNew ? "sr_create_script" : "sr_save_script", {}, {
    dataType: "",
    success: function() {
      apex.submit('PARSE');
    }
  });
});

},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"saveButton","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ gStoreScript('SAVE', false, function(saveNew) {
  apex.server.process(saveNew ? "sr_create_script" : "sr_save_script", {}, {
    dataType: "",
    success: function() {
      $("#codeEditor_widget").codeEditor("showNotification", 
        "<ul><li class='is-success'>" + apex.util.escapeHTML(apex.lang.getMessage("SCRIPTS.CHANGES_SAVED")) + "</li></ul>");
    }
  });
});

},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"B106549728476820975","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ gStoreScript('GET', false, function() {
  apex.submit('DOWNLOAD');
});

},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"B91124011966862772","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ apex.confirm(htmldb_delete_message,'DELETE');
},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"B108477306269478215","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ gStoreScript('CREATE', false, function() {
  apex.server.process("sr_create_script", {}, {
    dataType: "",
    success: function() {
      apex.submit('PARSE');
    }
  });
});

},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"B106937316772503576","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ gStoreScript('SAVE', true, function(saveNew) {
  apex.server.process(saveNew ? "sr_create_script" : "sr_save_script", {}, {
    dataType: "",
    success: function() {
      apex.submit('RUN');
    }
  });
});

},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"B164269527228796320","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ gStoreScript('CREATE', true, function() {
  apex.server.process("sr_create_script", {}, {
    dataType: "",
    success: function() {
      apex.submit('RUN');
    }
  });
});

},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"ITEM","triggeringElement":"P60_SCRIPT_NAME","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"change","anyActionsFireOnInit":true,actionList:[{"eventResult":true,"executeOnPageInit":true,"stopExecutionOnError":true,javascriptFunction:function (){ $("#saveButton")[0].disabled = $v("P60_SCRIPT_NAME") !== $v("P60_OLD_SCRIPT_NAME");
},"action":"NATIVE_JAVASCRIPT_CODE"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"CANCEL","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,"affectedElementsType":"REGION","affectedRegionId":"saveDialog",javascriptFunction:function() {apex.theme.closeRegion(this.affectedElements);},"action":"NATIVE_CLOSE_REGION"}]},
{"triggeringElementType":"BUTTON","triggeringButtonId":"B138360700895540644","bindType":"bind","executionType":"IMMEDIATE","bindEventType":"click","anyActionsFireOnInit":false,actionList:[{"eventResult":true,"executeOnPageInit":false,"stopExecutionOnError":true,javascriptFunction:function (){ apex.theme.closeRegion("saveDialog");
gStoreScript("REPLACE", g_run, function(saveNew) {
  apex.server.process("sr_replace_script", {}, {
    dataType: "",
    success: function() {
        apex.submit(g_run ? "REPLACE_RUN" : "PARSE");
    }
  });
});

},"action":"NATIVE_JAVASCRIPT_CODE"}]}];
}
</script>




<script nonce="EJWokLq_citvIT9ZcXO3Dw">
htmldb_delete_message='Would you like to perform this delete action?';
htmldb_dup_script_name='The script name exists already in your workspace.';
htmldb_rename_script_name='The script name exists already in your workspace and owned by another user.  Please enter different script name.';
htmldb_null_script_name='Script Name must be specified.';
htmldb_null_script='Script must be entered.';

let g_run = false;


function gStoreScript(req, run, cb) {
  let plsqlCode, scriptLength,
    saveNew = false,
    maxLength = $v("P60_MAX_LENGTH"),
    fileID = $v("P60_FILE_ID"),
    scriptName = $v("P60_SCRIPT_NAME");

  const alertOption = {
    style: "warning"
  };

  function dupNameCheck(cb) {
    let status = "";
    apex.server.process( "sr_dup_name", {
        pageItems: ["P60_SCRIPT_NAME", "P60_OLD_SCRIPT_NAME", "P60_FILE_ID"]
    }, {
      dataType: "text"
    }).done(function(data) {
      if ( data.substr(0,11) == 'FAIL_RENAME' ) {
        status = "FAIL_RENAME";
      } else if ( data.substr(0,4) == 'FAIL' ) {
        status = "FAIL";
      } else if ( data.substr(0,8) == 'SAVE_NEW' ) {
        status = "SAVE_NEW";
      } else {
        status = "SUCCESS";
      }
    }).always(function() {
      cb(status);
    });
  }

  function doSave() {
    apex.builder.plugin.codeEditor.saveProcess("#codeEditor_widget", "STORE_SCRIPT", "f01", {f02: fileID,f03: scriptName})
      .always(function() {
          cb(saveNew);
      });
  }

  plsqlCode = $("#codeEditor_widget").codeEditor("getValue");
  scriptLength = plsqlCode.length;

  if (!scriptName) {
    apex.message.alert( htmldb_null_script_name, () => {}, alertOption);
    return false;
  }
  if (!plsqlCode) {
    apex.message.alert( htmldb_null_script, () => {}, alertOption); 
    return false;
  }
  
  if (req !== 'GET' && req !== 'REPLACE') {
    if (scriptLength > maxLength) {  

     let scriptLengthFormated = apex.locale.formatNumber( scriptLength, "999G999G999G999G990" );
     let maxLengthFormated = apex.locale.formatNumber( maxLength, "999G999G999G999G990" );

     apex.message.alert(apex.lang.formatMessage( "SCRIPT.MAX_SCRIPT_SIZE",maxLengthFormated, scriptLengthFormated ),() => {}, alertOption);
     return false;
    }
 
    dupNameCheck(function(status) {
      if (status == 'FAIL') {
        g_run = run;
        apex.theme.openRegion("saveDialog");
        return;
      } else if (status == 'FAIL_RENAME') {
        apex.message.alert( htmldb_rename_script_name, () => {}, alertOption);
        return;
      } else if (status == 'SAVE_NEW' && req != 'CREATE') {
        saveNew = true;
      }
      doSave()
    });
  } else {
      doSave()
  }

  return true;
}


$(document).on("apexreadyend", function() {
  apex.jQuery(".a-Body, .a-Main, #codeEditor, #codeEditor > .a-Region-body, .a-MonacoEditor").addClass("resize");
  apex.theme.pageResizeInit();
});
</script>






<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/libraries/apex/minified/widget.toolbar.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/libraries/oraclejet/17.0.2/js/libs/require/require.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/libraries/apex/minified/requirejs.jetConfig.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/libraries/apex/minified/jetCommonBundle.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/js/minified/builder.plugin.codeEditor.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw" src="https://static.oracle.com/cdn/apex/24.2.8/apex_ui/js/minified/widget.codeEditor.min.js?v=24.2.8"></script>
<script nonce="EJWokLq_citvIT9ZcXO3Dw">
apex.session.initTimeouts(180,{"idle_time_ms":7187000,"life_time_ms":35684000,"max_idle_time_ms":7200000},'\u002Fords\u002Fr\u002Fapex\u002Fworkspace\u002Fhome','\u002Fords\u002Fr\u002Fapex\u002Fworkspace\u002Fhome');
apex.jQuery( function() {
apex.page.init( this, function() {
try {
(function(){var e = apex.jQuery("#adminMenu_menu", apex.gPageContext$);
if (e.hasClass("js-addActions")) {
  apex.actions.addFromMarkup(e);
}
e.menu({ slide: e.hasClass("js-slide")});
})();
(function(){var e = apex.jQuery("#helpMenu_menu", apex.gPageContext$);
if (e.hasClass("js-addActions")) {
  apex.actions.addFromMarkup(e);
}
e.menu({ slide: e.hasClass("js-slide")});
})();
(function(){apex.builder.plugin.codeEditor('#codeEditor_widget',{
"language":"plsql"
,"adjustableHeight":false
,"validate":false
,"queryBuilder":false
,"parsingSchema":"WKSP_JOHNSAPEXSPACE"
,"readOnly":false
,"ajaxIdentifier":"UkVHSU9OIFRZUEV-fjY1NzAwNzY2MzMzNDE0MjEyNQ\/R6ahwdV5Lz5d-ET0CGpt5oqppVviz8E4QO1l5JbVshPDGJMb6j1BVVYuez4X6mwFOy3JMe8jwkB9i5wM-lqWrQ"
,"diffEditor":false
,"aiEnabled":false
,"required":false
}
);})();
} catch(e) {apex.debug.error(e)};
apex.item.waitForDelayLoadItems().done(function() {
try {
(function(){apex.da.initDaEventList();
apex.da.init();})();


} finally {
apex.event.trigger(apex.gPageContext$,'apexreadyend');
};
});
});
});apex.pwa.cleanup( { serviceWorkerPath:'\u002Fords\u002Fr\u002Fapex\u002Fsql-workshop\u002Fsw.js?v=24.2.8-15647977042413\u0026lang=en' } );
</script>

</body></html>